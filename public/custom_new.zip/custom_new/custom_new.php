<?php
/*
Plugin Name: Custom Plugin
Description: This is the new plugin.
Version: 1.0
Author: Nirbhay Hathaliya
*/

function add_new_custom_plugin() {
    ?>
    <div class="wrap">
        <h1>New Plugin</h1>
    <?php
}

add_action('admin_menu', 'add_custom_plugin');

function add_custom_plugin() {
    add_menu_page(
        'Custom New Plugin',
        'Custom New',
        'manage_options',
        'custom-new',
        'add_new_custom_plugin',
        'dashicons-admin-network',
    ); 
}


// this is updated file